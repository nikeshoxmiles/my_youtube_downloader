from flask import Flask, render_template, request, jsonify
import yt_dlp
import os

app = Flask(__name__)

# 確保下載資料夾存在
if not os.path.exists('downloads'):
    os.makedirs('downloads')

# 首頁路由，顯示 HTML 頁面
@app.route('/')
def home():
    return render_template('index.html')  # 顯示網站頁面的 HTML 檔案

# 下載影片或音訊的功能
@app.route('/download', methods=['POST'])
def download_video():
    url = request.form['url']  # 取得使用者輸入的 YouTube 連結
    format_choice = request.form['format']  # 取得使用者選擇的格式

    # 設定下載選項
    try:
        if format_choice == "audio":
            # 僅下載音訊並轉換為 MP3 格式
            ydl_opts = {
                'format': 'bestaudio/best',  # 下載最佳音訊格式
                'postprocessors': [{
                    'key': 'FFmpegAudioConvertor',  # 使用 FFmpeg 轉換為 MP3 格式
                    'preferredcodec': 'mp3',  # 設定為 mp3 格式
                }],
                'outtmpl': 'downloads/%(title)s.%(ext)s',  # 設定下載檔案的儲存路徑與名稱
            }
        else:
            # 下載影片的設定（如果選擇的是影片）
            ydl_opts = {
                'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4',  # 優先選擇 MP4 格式
                'outtmpl': 'downloads/%(title)s.%(ext)s',  # 設定下載檔案的儲存路徑與名稱
            }

        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])

        filename = f"{url.split('=')[-1]}.mp3" if format_choice == "audio" else f"{url.split('=')[-1]}.mp4"

        return jsonify({
            "message": "下載成功",
            "filename": filename  # 返回影片或音訊檔案名稱
        })

    except Exception as e:
        # 如果發生錯誤，返回錯誤訊息
        return jsonify({
            "message": "下載失敗",
            "error": str(e)  # 返回錯誤訊息
        })

if __name__ == '__main__':
    app.run(debug=True, port=5001)
